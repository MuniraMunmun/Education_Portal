<?php
include '../pages/heading.php';
include '../authentication/Teacherlogin.php';
include '../authentication/Studentlogin.php';
include '../pages/navbar.php';
?>
<div  style="color:#355c26; font-size:22px;text-align:left; background-color:#c1d9d7;height:45px;font-family:verdana;padding:40px;">
       Notice for informing students... <br><br><br>
</div>
<br>

<div  style="font-size:22px;text-align:center; background-color:#9aa7ad;height:45px;font-family:sans-serif;">
        MD. Akhteruzzamzn Uploaded a File "Lecture-1" on Programming language course.<br><br><br>
	
</div>
<div  style="font-size:23px;text-align:center; background-color:#c1d9d7;height:45px;font-family:sans-serif;">
                  Remember that tomorrow will held a Assignment on Programming language.<br><br>
</div>

<div  style="font-size:22px;text-align:center; background-color:#9aa7ad;height:45px;font-family:sans-serif;">
        MD. Saifullah Sadi Uploaded a File "Lecture-3" on Programming language course.<br>

<div  style="font-size:23px;text-align:center; background-color:#c1d9d7;height:45px;font-family:sans-serif;">
                  Remember that tomorrow will held a Assignment on Database.<br><br>
</div>

<br>
<?php
include '../pages/footer.php';
?>
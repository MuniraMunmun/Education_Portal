<?php
include '../heading.php';
//include '../../db/connect.php';
include '../../authentication/Teacherlogin.php';
?>
<?php
include '../navbar.php';
?>

<div style="font-size:25px; font-family:vardana; background-color:#cbe2f2; color:black; padding:17px;">
    <div class="coursebton">
        <a href="/pages/teacher/ProgrammingTeacher.php">Programming Language<br></a>
    </div>
    <div class="coursebton">
        <a href="/pages/teacher/SoftwareEngineering.php">Software Engineering</a>
    </div>




</div>

<?php
include "../footer.php";
?>
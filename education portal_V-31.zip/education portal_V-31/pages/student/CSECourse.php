<?php
include '../heading.php';
// include '../../db/connect.php';
include '../../authentication/Studentlogin.php';
?>
<?php
include '../navbar.php';
?>

<div style="font-size:25px; font-family:sans-serif; background-color:#b6d8f0; color:black; padding:17px;">




	<div class="coursebton">
		<a href="ListOfInstructor_pro.php">Programming Language<br></a>
		<a href="ListOfInstructor_se.php"> Software Engineering<br></a>
	</div>






</div>

<?php
include "../footer.php";
?>
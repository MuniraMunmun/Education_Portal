<?php

$conn = mysqli_connect('localhost', 'root', '', 'ramr');
// session_start();
